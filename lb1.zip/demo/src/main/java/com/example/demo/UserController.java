package com.example.demo;

import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/users") // Все маршруты будут начинаться с /users
public class UserController {

    // Простейшая "база" пользователей в памяти
    private List<User> users = new ArrayList<>();

    // GET /users — получить всех пользователей
    @GetMapping
    public List<User> getAllUsers() {
        return users;
    }

    // GET /users/{id} — получить пользователя по id
    @GetMapping("/{id}")
    public User getUserById(@PathVariable int id) {
        if (id >= 0 && id < users.size()) {
            return users.get(id);
        }
        return null; // Для простоты, можно потом сделать обработку ошибок
    }

    // POST /users — добавить нового пользователя
    @PostMapping
    public User addUser(@RequestBody User user) {
        users.add(user);
        return user;
    }
}

// Класс User
class User {
    private String name;
    private int age;

    // Конструкторы
    public User() {}  // нужен для JSON
    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Геттеры и сеттеры
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
}
